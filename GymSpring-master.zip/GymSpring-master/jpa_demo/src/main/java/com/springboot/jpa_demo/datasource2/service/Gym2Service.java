package com.springboot.jpa_demo.datasource2.service;

import com.alibaba.fastjson.JSONObject;

public interface Gym2Service {
    public JSONObject allGym2();
}
