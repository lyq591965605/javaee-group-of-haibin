package com.bjtu.j2ee.sport_club.repository2;

import com.bjtu.j2ee.sport_club.domain.Coach;
import org.springframework.data.repository.CrudRepository;

public interface CoachRepository2 extends CrudRepository<Coach, Integer> {
}
