<template>
  <div>
    <p>这是个首页</p>
  </div>
</template>

<script>
    export default {
        name: "mianPageMsg"
    }
</script>

<style scoped>

</style>
