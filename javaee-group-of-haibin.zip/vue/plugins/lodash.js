import Vue from 'vue'
import lodash from 'lodash'

Vue.use(lodash)
