import '../theme/index.css'
import Vue from 'vue'
import ElementUI from 'element-ui'

// 适配 element-ui i18n
Vue.use(ElementUI)
