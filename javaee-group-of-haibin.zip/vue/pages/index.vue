<template>
  <div>
    <login></login>
  </div>
</template>

<script>
import login from '~/components/Login.vue'

export default {
  components: {
    login
  }
}
</script>

<style>

</style>

