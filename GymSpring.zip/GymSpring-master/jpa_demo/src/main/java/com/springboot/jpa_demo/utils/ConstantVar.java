package com.springboot.jpa_demo.utils;

public class ConstantVar {

    public static int SUCCESSFUL_CODE=200;
    public static int ID_EXIST=201;
    public static int ID_PASS_INCORRECT;


    public static String SUCCESSFUL_MESSAGE="success";
    public static String ID_PASS_INCORRECT_MSG="id or password incorrect";

}
